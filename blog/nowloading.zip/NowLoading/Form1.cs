﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;


namespace NowLoading
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        long fib(int n)
        {
            if (n <= 2) return 1;
            return fib(n - 1) + fib(n - 2);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // เพิ่มโค้ดส่วนนี้ (อย่าลืม using System.Threading; ด้วยนะครับ)
            Thread progressThread = new Thread(delegate()
            {
                ProgressForm progress = new ProgressForm();
                progress.ShowDialog();
            });
            progressThread.Start();

            // โค้ดที่ทำงานนานๆ
            listBox1.Items.Clear();
            for (int i = 1; i < 40; i++)
            {
                listBox1.Items.Add(String.Format("fib({0}) = {1}", i, fib(i)));
                listBox1.SelectedIndex = listBox1.Items.Count - 1;
            }

            // เมื่อทำงานเสร็จแล้ว อย่าลืมเรียกคำสั่งนี้ (ปิดหน้าต่าง loading)
            progressThread.Abort();
        }
    }
}
