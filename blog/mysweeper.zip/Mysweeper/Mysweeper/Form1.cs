﻿// Author: Natt Piyapramote <nattster at google mail>

using System;
using System.Drawing;
using System.ComponentModel;
using System.Text;
using System.Windows.Forms;

namespace Mysweeper
{
    public partial class frmMain : Form
    {
        const int cellwidth = 20;       // Size of Button
        const int cellheight = 20;

        Random random;                  
        int[,] field;                   // Minefields (-1 = Mine)
        int remainBomb = 0;             // # of ramaining bombs (for GUI)
        Button[,] buttons;              // Array of buttons
        Label[,] labels;                // Array of labels

        bool finished = true;           // Game Ended?       

        public frmMain()
        {
            InitializeComponent();
        }

        // return number of bomb surrounding (x, y)
        private int CountBombs(int x, int y)
        {
            int bombs = 0;
            for (int dy = -1; dy <= 1; dy++)
            {
                for (int dx = -1; dx <= 1; dx++)
                {
                    if (dx == 0 && dy == 0) continue;
                    if (x + dx < 0 || x + dx >= field.GetLength(0)) continue;
                    if (y + dy < 0 || y + dy >= field.GetLength(1)) continue;
                    if (field[x + dx, y + dy] == -1)
                        bombs++;
                }
            }
            return bombs;
        }

        // flood filling empty area
        private void FloodFill(int x, int y)
        {
            if (buttons[x, y].Visible == false) return;
            if (field[x, y] == 0)
                buttons[x, y].Visible = false;
            else if (field[x, y] == -1)
                return;
            else if (field[x, y] > 0)
            {
                buttons[x, y].Visible = false;
                return;
            }
            for (int dy = -1; dy <= 1; dy++)
            {
                for (int dx = -1; dx <= 1; dx++)
                {
                    if (dx == 0 && dy == 0) continue;
                    if (x + dx < 0 || x + dx >= field.GetLength(0)) continue;
                    if (y + dy < 0 || y + dy >= field.GetLength(1)) continue;
                    FloodFill(x + dx, y + dy);
                }
            }
        }

        // gameover!, show all bombs's position
        private void GameOver()
        {
            for (int y = 0; y < field.GetLength(1); y++)
            {
                for (int x = 0; x < field.GetLength(0); x++)
                {
                    if (field[x, y] == -1)
                        buttons[x, y].Visible = false;
                }
            }
            finished = true;
            MessageBox.Show("Game over!");
        }

        // test if game ended
        private void IsFinished()
        {
            // auto mark bomb if all other cell are opened
            bool all_opened = true;
            for (int y = 0; y < field.GetLength(1); y++)
            {
                for (int x = 0; x < field.GetLength(0); x++)
                {
                    if (field[x, y] > 0 && buttons[x, y].Visible)
                        all_opened = false;
                }
            }

            // all bomb defused?
            for (int y = 0; y < field.GetLength(1); y++)
            {
                for (int x = 0; x < field.GetLength(0); x++)
                {
                    if (all_opened && field[x, y] == -1)
                        buttons[x, y].Text = "B";
                    if (field[x, y] == -1 && buttons[x, y].Text == "")
                    {
                        return; // not all bomb defused yet
                    }
                }
            }

            // finished
            finished = true;
            for (int y = 0; y < field.GetLength(1); y++)
            {
                for (int x = 0; x < field.GetLength(0); x++)
                {
                    if (field[x, y] > 0)
                        buttons[x, y].Visible = false;
                }
            }
            MessageBox.Show("Congratulations!");
        }

        // start a new game
        private void NewGame(int bomb, int width, int height)
        {
            // remove old buttons and label (added to Windows.Controls array)
            if (buttons != null)
            {
                foreach (Button b in buttons)
                    this.Controls.Remove(b);
                foreach (Label l in labels)
                    this.Controls.Remove(l);
            }

            field = new int[width, height];             // initialize minefield
            remainBomb = bomb;
            lblRemain.Text = remainBomb.ToString() + " Bombs";
            
            // randomly place bomb in the field
            while (bomb > 0)
            {
                int x = random.Next(width);
                int y = random.Next(height);

                // is there any bomb at (x, y)?
                if (field[x, y] == -1)
                    continue;

                field[x, y] = -1; // place bomb at (x, y)
                bomb--;
            }

            // populate field statistics (number of surrounding bombs)
            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    if (field[x, y] == -1)
                        continue;
                    field[x, y] = CountBombs(x, y);
                }
            }
            // field values
            //   -1 == BOMB
            //   0  == 0 surrounding bombs
            //   1  == 1 surrounding bomb
            //   2  == 2 surrounding bombs
            //   ...

            // create control arrays for GUI
            buttons = new Button[width, height];
            labels = new Label[width, height];
            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    buttons[x, y] = new Button();
                    buttons[x, y].Left = x * cellwidth;
                    buttons[x, y].Top = y * cellheight + mainPanel.Height;
                    buttons[x, y].Width = cellwidth;
                    buttons[x, y].Height = cellheight;

                    labels[x, y] = new Label();
                    labels[x, y].Left = buttons[x, y].Left;
                    labels[x, y].Top = buttons[x, y].Top;
                    labels[x, y].Width = buttons[x, y].Width;
                    labels[x, y].Height = buttons[x, y].Height;
                    if (field[x, y] > 0)
                    {   // number
                        labels[x, y].Text = field[x, y].ToString();
                    }
                    else if (field[x, y] == -1)
                    {   // bomb
                        labels[x, y].ForeColor = Color.White;
                        labels[x, y].BackColor = Color.Red;
                        labels[x, y].Text = "B";
                    }
                    labels[x, y].TextAlign = ContentAlignment.MiddleCenter;

                    this.Controls.Add(buttons[x, y]);       // place button in front of label
                    this.Controls.Add(labels[x, y]);

                    // some event handlers (for left/right mouse click)
                    buttons[x, y].Click += new EventHandler(buttonClick);
                    buttons[x, y].MouseUp += new MouseEventHandler(buttonMouseUp);
                }
            }

            finished = false;   // reset game ended flag

            // resize windows form to fit the field
            this.Width = cellwidth * width+ (this.Width -this.ClientSize.Width);
            this.Height = cellheight * height + mainPanel.Height + (this.Height - this.ClientSize.Height);
        }

        void buttonMouseUp(object sender, MouseEventArgs e)
        {  
            // right mouse click

            if (finished) return;
            Button btn = (Button)sender;
            int x = btn.Left / cellwidth;
            int y = (btn.Top - mainPanel.Height) / cellheight;

            // mark button as B (Bomb)
            if(e.Button == MouseButtons.Right)
            {
                if (btn.Text == "B")
                {
                    btn.Text = "";
                    remainBomb++;
                }
                else
                {
                    btn.Text = "B";
                    remainBomb--;
                }
                lblRemain.Text = remainBomb.ToString() + " Bombs";
                IsFinished();
            }
        }

        void buttonClick(object sender, EventArgs e)
        {
            // left mouse click

            if (finished) return;
            Button btn = (Button)sender;
            int x = btn.Left / cellwidth;
            int y = (btn.Top - mainPanel.Height) / cellheight;

            // if marked, do nothing!
            if (buttons[x, y].Text == "B") return;

            if (field[x, y] == -1) // clicked on a bomb
                GameOver();
            else if (field[x, y] == 0)  // clicked on empty area
            {
                FloodFill(x, y);
                IsFinished();
            }
            else
            {
                btn.Visible = false;    // clicked on number
                IsFinished();
            }
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            random = new Random();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            NewGame(10, 10, 10);
            // initialize a new game
            // with 10 bombs in 10x10 field.
        }

        private void frmMain_Resize(object sender, EventArgs e)
        {
            button1.Left = this.Width - button1.Width - 20;
        }
    }
}
